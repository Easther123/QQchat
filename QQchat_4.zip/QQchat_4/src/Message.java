public class Message implements java.io.Serializable { //序列化

    private String mesType;

    private String sender;//发送者
    private String getter; //接收者
    private String con;  //信息

    public String getSender()
    {
        return sender;
    }
    public void setSender(String sender)
    {
        this.sender=sender;
    }

    public String getGetter()
    {
        return getter;
    }
    public void setGetter(String getter)
    {
        this.getter=getter;
    }

    public String getCon()
    {
        return con;
    }
    public void setCon(String con)
    {
        this.con=con;
    }



    public String getMesType()
    {
        return mesType;
    }

    public void setMesType(String mesType)
    {
        this.mesType =mesType;
    }

    public String getMesType_log()
    {
        return mesType;
    }

    public void setMesType_log(String mesType)
    {
        this.mesType =mesType;
    }
}