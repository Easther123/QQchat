
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TCPClient {
    public static void main(String[] args) throws IOException{
        int temp ; //用于存放读取到的文件的字节型数据
        Socket socket2 = null;
        OutputStream os = null;
        FileInputStream fis = null;
        try {
             //创建Socket对象,指定连接的主机地址 和 端口号
            socket2  = new Socket("127.0.0.1", 9999);

            String fileName;
            int num = 0;
            Scanner sc = new Scanner(System.in);
            System.out.println("请输入要传输的文件的绝对路径：(不要包含多余的空格、Tab)");
            fileName = sc.nextLine();
            String[] names = fileName.split("//");

            //发送文件数据给服务器
            fis = new FileInputStream(new File(fileName)); //要将文件的内容读取出来，所以用FileInputStream
            os = socket2.getOutputStream();

            //先将文件名发送过去
            byte[] sendname = names[names.length-1].getBytes("UTF-8");
            int namelen = sendname.length;
            os.write(namelen);    //传文件名的长度
            os.write(sendname);   //传文件名
            //发送文件内容
            System.out.print("即将读取文件！");
            while((temp=fis.read())!=-1){
                System.out.println("正在写入数据......");
                os.write(temp);
            }
            System.out.println("文件传输结束！");
        } catch (UnknownHostException e) {

            System.out.println( e);
        } catch (IOException e) {

            System.out.println( e);
        }
        finally{
            os.close();
            fis.close();
            socket2.close();
        }
    }
}