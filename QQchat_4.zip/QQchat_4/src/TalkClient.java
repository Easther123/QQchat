import java.io.*;
import java.net.*;
public class TalkClient {
    public static void main(String args[]) {
        try{
            //向本机的4700端口发出客户请求
            Socket socket=new Socket("127.0.0.1",4700);
            System.out.println(socket);//输出本客户端的编号，方便观察，可删除
            //由系统标准输入设备构造BufferedReader对象
            BufferedReader sin=new BufferedReader(new InputStreamReader(System.in));
            //由Socket对象得到输出流，并构造DataOutputStream对象
            DataOutputStream os=new DataOutputStream(socket.getOutputStream());
            //由Socket对象得到输入流，并构造相应的DataInputStream对象
            DataInputStream is=new DataInputStream(socket.getInputStream());
            String readline;
            System.out.println("样例输入：编号 消息      example：1 hello");
            while(true){//若从标准输入读入的字符串为 "bye"则停止循环
                if(sin.ready())//DataOutputStream特有的方法，在不读取的情况下，查看缓冲区是否有可读取的内容
                {//如果键盘有输入，即先发消息
                    readline=sin.readLine();
                    os.writeUTF(readline);;
                    os.flush();//刷新输出流，使Server马上收到该字符串
                    if(readline.equals("bye"))
                    {
                        break;
                    }
                }
                if(is.available()>0)//如果先收消息，也是先available()查看输入流的长度（未读取的情况下）
                {
                    System.out.println(is.readUTF());
                }
            } //继续循环
            os.close(); //关闭Socket输出流
            is.close(); //关闭Socket输入流
            socket.close(); //关闭Socket
        }catch(Exception e) {
            System.out.println("Error"+e); //出错，则打印出错信息
        }
    }
}
