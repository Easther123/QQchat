import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
//服务器端控制界面


public class ControlPanel  extends JFrame implements ActionListener{
    JPanel jp1;
    JButton jstart,jend;

     ControlPanel()
    {   Font font = new Font("宋体",Font.PLAIN,30);

        jp1=new JPanel();
        jstart=new JButton("启动服务器");
        jstart.addActionListener(this);
        jend=new JButton("关闭服务器");
        jstart.setFont(font); jend.setFont(font);
        jstart.setForeground(Color.BLUE); jend.setForeground(Color.BLUE);

        jp1.add(jstart);
        jp1.add(jend);

        add(jp1);
        setLocation(150,150);
        setSize(900,900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //结束窗口所在的应用程序
        setVisible(true);
    }

    public static void main(String[] args) {
         new ControlPanel();
     }

    public void actionPerformed(ActionEvent arg0)
    {
        if(arg0.getSource()==jstart)
        {
            new MyQqServer();
        }
    }
}


class MyQqServer  {

    public MyQqServer () {
        try {
            System.out.println("服务器启动");
            ServerSocket ss=new ServerSocket(9999);
            while(true)
            {
                Socket s = ss.accept();

                //接收客户端发来的信息
                ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
                User u=(User)ois.readObject();
                System.out.println("用户Id:"+u.getUserId()+"  密码"+u.getPasswd());
                Message m=new Message();
                ObjectOutputStream oos=new ObjectOutputStream(s.getOutputStream());
                if(u.getPasswd().equals("123456"))
                {
                    //返回一个成功登录的信息
                    m.setMesType_log("1");    //mesType1 =1  表明登陆成功
                    oos.writeObject(m);
                    //单开一个线程,让该线程与该客户端保持通信
                    SerConClientThread scct=new SerConClientThread(s);
                    ManageClientThread.addClientThread(u.getUserId(),scct);//放到HashMap
                    scct.start(); //启动与该客户端通信的线程
                } else {
                    m.setMesType_log("2");
                    oos.writeObject(m);
                    s.close();  //关闭连接(流)
                }
            }
        }
        catch(Exception e)
        {
            System.out.println( e);
        }

    }
}

//服务器和客户端的通信线程
class SerConClientThread extends Thread    //继承Thread类
 {
     static Socket s;

     public SerConClientThread(Socket s) {
         this.s = s;  //把服务器和该客户端的连接赋给s;
         // 创建并启动服务端输入线程
         ServerInputThread inputThread = new ServerInputThread(this);
         inputThread.start();
     }
     public void run() {

         while (true) {
             //这里该线程就可以接受客户端的信息
             try {
                     ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
                     Message m = (Message) ois.readObject();
                     System.out.println(m.getSender() + "给 " + m.getGetter() + "发送: " + m.getCon());
                     //拿到发送者与服务器的socket,此时就需要hashmap;
                     SerConClientThread sc = ManageClientThread.getClientThread(m.getGetter());
                     ObjectOutputStream oos = new ObjectOutputStream(sc.s.getOutputStream()); //接受人的通信线程;
                     oos.writeObject(m);
             }catch(Exception e) {
                 System.out.println( e);
                 }
             }
         }
 }



 class ServerInputThread extends Thread {
    private SerConClientThread clientThread;

    public ServerInputThread(SerConClientThread clientThread) {
        this.clientThread = clientThread;
    }

    public void run() {
        while (true) {
            try {
                Scanner scanner = new Scanner(System.in);

                while (true) {
                    String message = scanner.nextLine();
                    // 构建 Message 对象
                    Message serverMessage = new Message();
                    serverMessage.setMesType(message);
                    // 向客户端发送消息
                    ObjectOutputStream oos = new ObjectOutputStream(clientThread.s.getOutputStream());
                    oos.writeObject(serverMessage);
                    oos.flush();
                }
            } catch (IOException e) {
                System.out.println( e);
            }
        }
    }
}

