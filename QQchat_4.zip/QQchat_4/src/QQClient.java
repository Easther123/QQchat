import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.*;
import java.net.Socket;
import java.awt.event.*;



// 客户端的登陆界面
class QqClientlLogin  extends JFrame implements ActionListener {  //JFrame的子类

    JLabel jup;   //定义上部需要的组件
    JPanel jmid ; //定义中部需要的组件
    JLabel jmid_num1,jmid_key1;
    JTextField jmid_num2;    //文本框
    JPasswordField jmid_key2;   //密码框
    JCheckBox jmid_rember,jmid_automatic;  //复选框

    JPanel  jdown;         //JPanel 面板
    JButton jdown_1,jdown_2;    //定义下部需要的组件

    public  QqClientlLogin()
    {
        //处理上部
        jup=new JLabel(new  ImageIcon("src/image/up3.png"));

        //处理中部
        jmid=new JPanel(new GridLayout(3,3));//网格布局 3行3列
        Font font = new Font("宋体", Font.PLAIN, 25);    //创建1个字体实例
        jmid_num1=new JLabel("QQ号码:",JLabel.CENTER);
        jmid_key1=new JLabel("QQ密码:",JLabel.CENTER);
        jmid_num1.setFont(font);    jmid_key1.setFont(font);  //字体大小
        jmid_num2= new JTextField() ;
        jmid_key2=new JPasswordField();
        jmid_rember=new JCheckBox("自动登录");
        jmid_automatic=new JCheckBox("记住密码");
        jmid_rember.setFont(font);
        jmid_automatic.setFont(font); //字体大小
        jmid_rember.setForeground(Color.blue);
        jmid_automatic.setForeground(Color.blue);
        jmid.add(jmid_num1);
        jmid.add(jmid_num2);
        jmid.add(jmid_key1);
        jmid.add(jmid_key2);
        jmid.add(jmid_rember);
        jmid.add(jmid_automatic);

        //处理下部
        jdown=new JPanel(new FlowLayout()); //流式布局
        jdown_1=new JButton(new ImageIcon("src/image/denglu.png"));

        //响应用户点击登录
        jdown_1.addActionListener(this);  //监控

        jdown_2=new JButton(new ImageIcon("src/image/tuichu.png"));
        jdown.add(jdown_1);
        jdown.add(jdown_2);

        setLocation(300,300); //窗口的位置
        add(jup,"North");   //放在最北部
        add(jmid,"Center");  //放在中间
        add(jdown,"South"); //放在南部
        setSize(700,540);     //设置大小
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //结束窗口所在的应用程序
        setVisible(true);       //可见,默认是不可见
    }

    public static void main(String[]  args) {
        new  QqClientlLogin();
    }
    public void actionPerformed(ActionEvent arg0)
    {
        if(arg0.getSource()==jdown_1);   //请求登录
        {
            User u=new User();
            u. setUserId(jmid_num2.getText().trim());   //trim() 方法用于删除字符串的头尾空白符
            u. setPasswd(new String (jmid_key2.getPassword()));   //字符串;
            QqClientUser qqclientuser=new QqClientUser();

            if(qqclientuser.checkUser(u))
            {
                new QqFriendList(u.getUserId());  //好友列表
                this.dispose();  //关闭登陆界面
            }else
            {
                JOptionPane.showMessageDialog(this,"用户名或密码错误");
                //JOptionPane弹窗,消息提示框
                //第一个参数-确定Frame在其中显示的对话框
                //第二个参数message在提示框里显示的信息
            }
        }
    }
}


  class QqFriendList extends JFrame implements ActionListener, MouseListener {
    //负责创建监听器的类,  点击按钮触发ActionListener事件;  鼠标监听MouseListener

    String owner;

    // 卡片(我的好友);
    JPanel jup1,jmid1;   //jup1即为总JPanel;
    JButton jup1_1;
    JScrollPane jmid1_1;


    //把整个JFrame设置成CardLayout布局
    CardLayout cl;

    public  QqFriendList (String ownerId)
    {
        Font font = new Font("宋体", Font.PLAIN, 35);    //创建字体实例

        owner=ownerId;
        //处理卡片(我的好友);
        jup1=new JPanel(new BorderLayout());
        jup1_1=new JButton("我的好友");
        jup1_1.setFont(font);  //字体

        //假设有2个好友,具体是服务器返回的结果(好友信息存放在服务器)
        jmid1=new JPanel(new  GridLayout(2,1,4,4));  //(4,4)行间距和列间距
        //给jmid1初始化2个好友
        JLabel []jlist1=new JLabel [3];  //数组;
        for ( int i=1; i<jlist1.length ; i++ )
        {
            jlist1[i]=new JLabel(i+1+" ",new ImageIcon("src/image/touxiang.png"),JLabel.LEFT);
            jlist1[i].addMouseListener(this);
            jmid1.add(jlist1[i]);
        }
        jmid1_1=new JScrollPane(jmid1);
        jup1.add(jup1_1,"North");
        jup1.add(jmid1_1,"Center");
        cl=new CardLayout();
        setLayout(cl);
        add(jup1,"1");
        setTitle(ownerId);//显示自己的编号
        setLocation(300,300); //窗口的位置
        setSize(440,800);
        setVisible(true);
    }


    public void mouseEntered(MouseEvent arg0) {    //进入组件触发鼠标事件

        JLabel jl=(JLabel)arg0.getSource(); //变成JLable形式
        //getSource()获取鼠标事件的事件源;
        jl.setForeground(Color.red);
    }

    public void mouseExited(MouseEvent arg0) {  //鼠标离开组件触发的鼠标事件

        JLabel jl=(JLabel)arg0.getSource();
        jl.setForeground(Color.black);
    }

    public void mouseClicked(MouseEvent arg0) {   //点击鼠标触发鼠的标事件

        //响应用户双击的事件，并得到好友的编号.
        if(arg0.getClickCount()==2)   //getClickCount() 获取鼠标被单机的次数
        {
            //得到该好友的编号
            //getText() 的意思是：返回数据窗口控件中 悬浮在当前行列之上的
            String friendNum=((JLabel)arg0.getSource()).getText();
            QqChat qqChat=new QqChat(owner,friendNum);  //传入编号
            Thread t=new Thread(qqChat);
            t.start();     // 启动线程
        }
    }


     //不让 QqFriendList抽象化，因为后面实例化要用到，所以重写抽象方法
      @Override
      public void mousePressed(MouseEvent e) {

      }

      @Override
      public void mouseReleased(MouseEvent e) {

      }


      @Override
     public void actionPerformed(ActionEvent e) {

     }
 }

//与好友聊天的界面
class QqChat extends JFrame implements ActionListener,Runnable{  //监听发送按钮
    Font font = new Font("宋体", Font.PLAIN, 20); //实现Runnable接口实现多线程，
    JTextArea jta; //文本域  存聊天内容
    JTextField jtf; //文本框
    JButton jb;
    JPanel jp;
    String ownerId;
    String friendId;


    public QqChat(String owner,String friend)
    {
        ownerId= owner;
        friendId=friend;
        jta=new JTextArea();
        jtf=new JTextField(25);     //25个字符那么宽
        jb=new JButton("发送");
        jb.addActionListener(this);
        jb.setFont(font);
        jp=new JPanel();
        jp.add(jtf);
        jp.add(jb);
        add(jta,"Center");
        add(jp,"South");
        setTitle("你正在和 "+friend+" 聊天");  //设置标题
        setIconImage((new ImageIcon("src/image/qq.png").getImage())); //获取图像
        setLocation(800,400); //窗口的位置
        setSize(600, 500);
        setVisible(true);
    }


    public void actionPerformed(ActionEvent arg0) {

        if(arg0.getSource()==jb)//如果用户点击了发送按钮
        {
            Message m=new Message();
            m.setSender(this.ownerId);
            m.setGetter(this.friendId);
            m.setCon(jtf.getText());   //文本框中得到


            String currentText = jta.getText(); // 获取当前文本域中的文本
            String newMessage = "你说: " + m.getCon()+"\r\n";// 构造新消息

            if (!currentText.isEmpty()) {
                // 如果文本域不为空，将新消息追加到现有文本后面，并添加换行符
                jta.setText(currentText + "\n" + newMessage);
            } else {
                // 如果文本域为空，直接设置为消息内容
                jta.setText(newMessage);
            }

            // 清空文本框
            jtf.setText("");

            //发送给服务器
            try
            {
                ObjectOutputStream oos=new ObjectOutputStream(QQClient.s.getOutputStream());
                oos.writeObject(m);
            }
            catch (Exception e)
            {
                System.out.println( e);
            }
        }
    }
    public void run()
    {
        while(true)
        {   //一直处于读取状态(如果读不到就等待)
            try
            {ObjectInputStream ois=new ObjectInputStream(QQClient.s.getInputStream());
                Message m =(Message)ois.readObject();
                if (!m.getMesType().isEmpty()) {
                    // 如果文本域不为空，将新消息追加到现有文本后面，并添加换行符
                    if(m.getMesType().contains("//")){
                        //如果传输的内容含有//，则说明传的为文件，可以实现文件传输
                        new TCPServer();
                        new TCPClient();
                    }

                    this.jta.append( "\n"+"服务端说:" +m.getMesType());
                } else {
                    // 如果文本域为空，直接设置为消息内容
                    this.jta.append(m.getMesType());
                }
            }
            catch(Exception e)
            {
                System.out.println( e);
            }
        }
    }
}

class QqClientUser {

    public boolean checkUser(User u)
    {
        return new QQClient().sendLoginInfotoSSErver(u);
    }
}

//客户端链接服务器的部分
public class QQClient{

    public static Socket s;

    //发送第一次请求,登录请求
    public boolean sendLoginInfotoSSErver(Object o) //发送对象到服务器
    {
        boolean b=false;
        try
        {
            s=new Socket("127.0.0.1",9999);	 //传入要连接主机与端口
            ObjectOutputStream oos=new ObjectOutputStream(s.getOutputStream()); //输出流
            oos.writeObject(o);  //把o发出去

            ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
            Message ms=(Message)ois.readObject();
            if(ms.getMesType().equals("1"))
                b=true;
        }
        catch (Exception e) {
            System.out.println( e);
        }
        return b;
    }
}

