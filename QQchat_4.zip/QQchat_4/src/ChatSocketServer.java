import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


 //发送消息的线程
class Send extends Thread{
    private Socket socket;//与客户端对应的socket对象
    public Send(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        this.sendMsg();
    }
    //发送消息
    private  void sendMsg(){
        try(Scanner scanner = new Scanner(System.in);
            //创建向对方发送消息的输出流
            PrintWriter pw = new PrintWriter(socket.getOutputStream())
        ){
            while (true){
                String msg = scanner.nextLine();
                pw.println(msg);
                pw.flush();
            }
        }catch (Exception e) {
            System.out.println( e);
        }
    }
}


//接收消息的线程
class Receive extends Thread{
    //与客户端对应的Socket对象
    private Socket socket;
    public Receive(Socket socket){
        this.socket = socket;
    }

    @Override
    public void run() {
        this.receiveMsg();
    }
    private  void receiveMsg(){
        try(BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            while (true){
                String msg = br.readLine();
                System.out.println("客户端："+msg);
            }

        }catch (Exception e) {
            System.out.println( e);
        }
    }
}



//接收消息的线程
public class ChatSocketServer {
    public static void main(String[] args) {
        try(ServerSocket serverSocket = new ServerSocket(4445)){
            System.out.println("服务端启动，等待连接.....");
            Socket socket = serverSocket.accept();
            System.out.println("连接成功");
            //将与客户端对应的Socket对象传递给发送消息的线程，并启动该线程
            new Send(socket).start();
            new Receive(socket).start();
        }catch (Exception e) {
            System.out.println( e);
        }
    }
}