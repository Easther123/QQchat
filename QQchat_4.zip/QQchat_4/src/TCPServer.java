import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class TCPServer   {
    public static void main(String[] args){
        ServerSocket serverSocket ;
        Socket socket = null;
        FileOutputStream fos = null;
        try {
            serverSocket = new ServerSocket(9999);

            System.out.println("***服务器已经启动，等待客户端的连接***");
            socket = serverSocket.accept();

            InputStream is ;
            int temp ,len=0;

            int typelen;
            is = socket.getInputStream();
            typelen = is.read();
            byte[] bs = new byte[typelen];
            while(len != typelen){
                bs[len] = (byte) is.read();
                len++;
            }
            String name = new String(bs,"UTF-8");  //注意编码格式
            //创建文件
            File f = new File(name);
            f.createNewFile();   //创建的文件保存的地方，与当前文件的路径一致
            fos = new FileOutputStream(f,true); //以追加的形式写入文件

            //将接收到的数据写入文件
            while((temp = is.read()) != -1){
                fos.write(temp);
            }
            System.out.println("已成功接收" + name + "文件");
        } catch (IOException e) {

            System.out.println( e);
        }finally{
            try {
                fos.close();
                socket.close();
            } catch (IOException e) {
                System.out.println( e);
            }
        }
    }
}