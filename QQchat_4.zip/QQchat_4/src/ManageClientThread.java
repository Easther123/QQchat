import java.util.HashMap;
//管理客户端线程
public class ManageClientThread {

    public static HashMap hm=new HashMap<String, SerConClientThread>();

    //向hm中添加一个客户通讯线程
    public static void addClientThread(String uid,SerConClientThread ct)
    {
        hm.put(uid, ct);
    }

    //返回socket
    public static SerConClientThread getClientThread(String uid)
    {
        return (SerConClientThread) hm.get(uid);
    }

}
