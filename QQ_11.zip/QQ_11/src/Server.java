import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Server {
    public static void main(String[] args) {
        //保存客户端处理的线程
        Vector<UserThread> vector = new Vector <>();
        //固定大小的线程池，用来处理不同客户端
        ExecutorService es = Executors.newFixedThreadPool(5);
        //创建服务器端的Socket
        try {
            ServerSocket server = new ServerSocket(8888);
            System.out.println("服务器启动，正在等待连接...");
            while(true){
                Socket socket = server.accept();
                UserThread user = new UserThread(socket,vector);
                es.execute(user);  //开启线程
            }
        } catch (IOException e) {
            System.out.println( e);
        }
    }
}


class UserThread implements Runnable{
    private String name;
    private Socket socket;
    private Vector<UserThread> vector;
    private ObjectInputStream oIn;
    private ObjectOutputStream oOut;
    private boolean flag = true;

    public UserThread(Socket socket, Vector<UserThread> vector) {
        this.socket = socket;
        this.vector = vector;
        vector.add(this);    //把当前线程也加入vector中
    }

    @Override
    public void run() {
        try {
            //1、构造输入输出流
            System.out.println("客户端：" + socket.getInetAddress().getHostAddress() + "已连接！");
            oIn = new ObjectInputStream(socket.getInputStream());
            oOut = new ObjectOutputStream((socket.getOutputStream()));

            while(flag){
                Message message = (Message)oIn.readObject();
                int type = message.getType();
                switch (type){
                        case MessageType.TYPE_SEND:
                        String to = message.getTo();//发送给谁
                        UserThread ut;
                        if(to.equals("chat_room")){
                            System.out.println(message.getFrom()+"说："+message.getInfo());
                        }
                        //遍历vector，找到接收信息的客户端
                        int size = vector.size();
                        for (int i = 0; i < size; i++) {
                            ut = vector.get(i);
                            if(to.equals(ut.name) && ut != this){
                                ut.oOut.writeObject(message);
                            }
                        }
                        break;

                    case MessageType.TYPE_LOGIN:
                        name = message.getFrom();//获取用户名
                        message.setInfo("欢迎您！");
                        oOut.writeObject(message);
                        break;}
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println( e);
        }
    }
}