import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;


public class TCPServer {
    public static void main(String[] args){
        Socket socket = null;
        FileOutputStream fos = null;
        try {
            InputStream is ;
            int temp ,len=0;
            int typelen;
            is = socket.getInputStream();
            typelen = is.read();
            byte[] bs = new byte[typelen];
            while(len != typelen){
                bs[len] = (byte) is.read();
                len++;
            }
            String name = new String(bs,"UTF-8");  //注意编码格式
            //创建文件
            File f = new File(name);
            f.createNewFile();   //创建的文件保存的地方，与当前文件的路径一致
            fos = new FileOutputStream(f,true); //以追加的形式写入文件
            while((temp = is.read()) != -1){//将接收到的数据写入文件
                fos.write(temp);
            }
            System.out.println("已成功接收" + name + "文件");
        } catch (IOException e) {

            System.out.println( e);
        }finally{
            try {
                fos.close();
                socket.close();
            } catch (IOException e) {
                System.out.println( e);
            }
        }
    }
}