import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Client {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //单线程池
        ExecutorService es = Executors.newSingleThreadExecutor();
        try {
            //创建客户端
            Socket socket = new Socket("127.0.0.1", 8888);
            System.out.println("服务器连接成功！");
            //构建输出输入流
            ObjectOutputStream oOut = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream oIn = new ObjectInputStream(socket.getInputStream());
            //1、客户端登录处理

            System.out.println("请输入名称：");
            String name = input.nextLine();
            Message message = new Message(name, null, MessageType.TYPE_LOGIN, null);
            oOut.writeObject(message);
            message = (Message) oIn.readObject();
            //打印服务器返回的信息+当前客户端的名字
            System.out.println(message.getInfo() + message.getFrom());
            //2、启动读取消息的线程
            es.execute(new readInfoThread(oIn));  //读取线程完成

            //3、发送消息
            //使用主线程来发送消息
            boolean flag = true;
            while(flag){
                //封装需要发送的消息对象
                message = new Message();
                System.out.println("To：");
                message.setTo(input.nextLine());
                if(input.nextLine().equals("chat_room")){
                    System.out.println("Info：");
                    message.setInfo(input.nextLine());
                    message.setFrom(name);
                    message.setType(MessageType.TYPE_SEND);
                    //发送给服务器
                    oOut.writeObject(message);
                }
                message.setFrom(name);
                message.setType(MessageType.TYPE_SEND);
                System.out.println("Info：");
                message.setInfo(input.nextLine());

                //发送给服务器
                oOut.writeObject(message);
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println( e);
        }
    }
}


// 读取其他客户端发来消息
class readInfoThread implements Runnable {
    private ObjectInputStream oIn; //输入流
    private boolean flag = true;

    public readInfoThread(ObjectInputStream oIn) {
        this.oIn = oIn;
    }


    @Override
    public void run() {
        try {
            while (flag) {
                Message message = (Message) oIn.readObject();
                if(message.getInfo().contains("//")){  //如果传输的内容含有//，则说明传的为文件，可以实现文件传输
                    new TCPServer();
                    new TCPClient();
                }
                System.out.println("[" + message.getFrom() + "]对我说：" + message.getInfo());  //输出用户名+内容
            }
            if(oIn != null){ //没有数据就关闭
                oIn.close();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println( e);
        }

    }
}